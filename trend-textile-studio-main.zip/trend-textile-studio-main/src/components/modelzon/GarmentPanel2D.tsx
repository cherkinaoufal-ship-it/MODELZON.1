/**
 * Real 2D garment simulation for the Design Layout sheet: body + collar +
 * sleeves silhouette per side, with the side's artwork composited into the
 * print area (instead of an empty box).
 */
export default function GarmentPanel2D({
  side,
  garment,
  color,
  artworkUrl,
  active,
}: {
  side: "front" | "back";
  garment: string;
  color: string;
  artworkUrl?: string | null;
  active?: boolean;
}) {
  const hooded = garment === "hoodie" || garment === "zip" || garment === "hood";
  const stroke = active ? "#22d3ee" : "rgba(255,255,255,0.35)";

  return (
    <svg viewBox="0 0 200 240" className="w-full h-full" aria-hidden>
      {/* sleeves */}
      <path d="M56 54 L18 92 L14 132 L44 140 L52 96 Z" fill={color} stroke={stroke} strokeWidth="2.5" strokeLinejoin="round" opacity="0.95" />
      <path d="M144 54 L182 92 L186 132 L156 140 L148 96 Z" fill={color} stroke={stroke} strokeWidth="2.5" strokeLinejoin="round" opacity="0.95" />
      {/* body */}
      <path d="M56 54 C74 42 82 38 100 38 C118 38 126 42 144 54 L150 214 C126 224 74 224 50 214 Z" fill={color} stroke={stroke} strokeWidth="2.5" strokeLinejoin="round" />
      {/* collar / hood */}
      {hooded ? (
        <path d="M74 46 C82 12 118 12 126 46 C116 58 84 58 74 46 Z" fill={color} stroke={stroke} strokeWidth="2.5" />
      ) : (
        <path d="M80 40 C88 54 112 54 120 40" fill="none" stroke={stroke} strokeWidth="3" />
      )}
      {/* back yoke seam / front placket hint */}
      {side === "back" ? (
        <path d="M62 66 C80 74 120 74 138 66" fill="none" stroke="rgba(0,0,0,0.3)" strokeWidth="1.6" strokeDasharray="5 4" />
      ) : (
        <path d="M100 52 V96" fill="none" stroke="rgba(0,0,0,0.25)" strokeWidth="1.6" strokeDasharray="5 4" />
      )}
      {/* hem + cuffs */}
      <path d="M50 206 C74 216 126 216 150 206" fill="none" stroke="rgba(0,0,0,0.25)" strokeWidth="1.6" strokeDasharray="5 4" />
      {/* print area / artwork */}
      {artworkUrl ? (
        <image href={artworkUrl} x="66" y="82" width="68" height="80" preserveAspectRatio="xMidYMid meet" />
      ) : (
        <rect x="66" y="82" width="68" height="80" rx="4" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="1.4" strokeDasharray="4 4" />
      )}
    </svg>
  );
}
