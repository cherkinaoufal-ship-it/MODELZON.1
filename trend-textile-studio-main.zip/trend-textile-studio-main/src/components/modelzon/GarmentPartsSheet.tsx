import { useState } from "react";
import { X } from "lucide-react";
import { GARMENT_PARTS, PART_CATEGORIES, type GarmentPartCategory } from "@/lib/garmentPartsLibrary";
import { FABRIC_EFFECTS } from "@/lib/fabricEffects";

/**
 * Full-screen garment-parts picker (hood / collar / pocket / sleeve /
 * closure + fabric effects), in the spirit of the M1M4 reference sheets.
 * Picking a shape hands its data URL back so it is added to the design
 * immediately through the normal decal system.
 */
export default function GarmentPartsSheet({
  open,
  onClose,
  onPick,
  ar,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (dataUrl: string, label: string) => void;
  ar: boolean;
}) {
  const [cat, setCat] = useState<GarmentPartCategory | "effects">("hood");
  const t = (en: string, arText: string) => (ar ? arText : en);
  if (!open) return null;

  const items =
    cat === "effects"
      ? FABRIC_EFFECTS.map((e) => ({ id: e.id, dataUrl: e.dataUrl, label: ar ? e.ar : e.en }))
      : GARMENT_PARTS.filter((p) => p.category === cat).map((p) => ({ id: p.id, dataUrl: p.dataUrl, label: ar ? p.ar : p.en }));

  return (
    <div className="fixed inset-0 z-[70] bg-black/85 backdrop-blur-sm flex flex-col" dir={ar ? "rtl" : "ltr"}>
      <div className="flex items-center gap-2 p-4 border-b border-white/10">
        <h2 className="text-base font-black text-white">{t("Garment parts", "أجزاء الملابس")}</h2>
        <button onClick={onClose} className="ml-auto w-9 h-9 grid place-items-center rounded-xl bg-white/10 text-white">
          <X size={18} />
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto px-4 py-3">
        {[...PART_CATEGORIES, { id: "effects" as const, en: "Effects", ar: "تأثيرات" }].map((c) => (
          <button
            key={c.id}
            onClick={() => setCat(c.id as GarmentPartCategory | "effects")}
            className={`shrink-0 px-3 py-1.5 rounded-full text-[11px] font-black border transition ${
              cat === c.id
                ? "bg-gradient-to-r from-cyan-400/30 to-fuchsia-400/30 border-cyan-300 text-white"
                : "bg-white/[0.05] border-white/10 text-white/60"
            }`}
          >
            {t(c.en, c.ar)}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-4 pb-8">
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
          {items.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onPick(item.dataUrl, item.label);
                onClose();
              }}
              className="rounded-2xl bg-white/95 border border-white/10 hover:border-cyan-400 p-2 flex flex-col items-center gap-1 transition"
            >
              <img src={item.dataUrl} alt={item.label} className="w-full aspect-square object-contain" />
              <span className="text-[10px] font-bold text-black/70 leading-tight text-center">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
